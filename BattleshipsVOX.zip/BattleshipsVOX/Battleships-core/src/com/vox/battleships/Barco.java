package com.vox.battleships;

public class Barco extends Battleships
{
	private int tamanho;//tamanho do navio
	private boolean estado;

					//"n" � proveniente do contador no la�o de repeti��o do construtor do tabuleiro
					//a partir dele � possivel saber o tamanho que o navio deve ter
					//garantindo sempre o numero proposto de navios e no modo proposto
					
	Barco(int n)
	{
		if(n == 1)					//para gerar um barco de 5
			tamanho = 5;
		else if(n == 2 || n == 3)	//para gerar dois barcos de 4
			tamanho = 4;
		else if(n > 3 && n < 7)		//para gerar tr�s barcos de 3
			tamanho = 3;
		else if(n >= 7)				//para gerar quatro barcos de 2
			tamanho = 2;
		estado = true;
	}
	
	public void setEstado(boolean e){
		estado = e;
	}
	
	public boolean getEstado(){
		return estado;
	}
	
	public int getTamanho(){		//m�todo para obter o tamanho do navio
		return tamanho;
	}
	
	
}
