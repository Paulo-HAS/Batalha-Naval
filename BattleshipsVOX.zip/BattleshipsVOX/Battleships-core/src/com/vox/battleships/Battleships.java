package com.vox.battleships;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;

public class Battleships extends ApplicationAdapter 
{
	public static int WIDTH = 800;
	public static int HEIGHT = 600;
	
	SpriteBatch batch;
	Texture img;
	Sprite playButton;
	Vector3 clickPos;
	OrthographicCamera camera;
	
	@Override
	public void create () 
	{
		batch = new SpriteBatch();
		img = new Texture("play_button.png");
		playButton = new Sprite(img);
		playButton.setCenter(400,300);
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 800, 600);
		Gdx.gl.glClearColor(1, 1, 1, 1);
	}

	@Override
	public void render () 
	{
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		batch.begin();
		
			playButton.draw(batch);
			desenhaTabuleiro();
		
		batch.end();
	}
	
	private void desenhaTabuleiro()
	{
		clickPos = new Vector3(Gdx.input.getX(),Gdx.input.getY(),0);
		camera.unproject(clickPos);
		
		if (clickPos.x >= 393.5f && clickPos.x <= 780.5f) 			//Posi��o do bot�o de Play
		{
			if (clickPos.y >= 254  && clickPos.y <= 346) 
			{
				boolean click = Gdx.input.justTouched();
					
				if (click == true) 
				{
					//Tabuleiro();           Chama construtor do tabuleiro
				}
			}
		}
	}
}
