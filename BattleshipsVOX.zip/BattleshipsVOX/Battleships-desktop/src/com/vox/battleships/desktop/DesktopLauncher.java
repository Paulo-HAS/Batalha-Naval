package com.vox.battleships.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.vox.battleships.Battleships;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		new LwjglApplication(new Battleships(), config);
		
		config.width = Battleships.WIDTH;
		config.height = Battleships.HEIGHT;
	}
}
